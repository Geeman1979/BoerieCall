-- BoerieCall Database Schema for Supabase
-- Run this in the Supabase SQL Editor

-- =============================================
-- TABLES
-- =============================================

CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  password TEXT NOT NULL,
  phone TEXT,
  address TEXT,
  city TEXT DEFAULT 'Other',
  role TEXT DEFAULT 'BUYER' CHECK (role IN ('BUYER', 'RESELLER', 'ADMIN')),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS products (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  category TEXT NOT NULL CHECK (category IN ('COLD_SMOKED', 'HOT_SMOKED', 'BILTONG', 'ACCESSORIES')),
  subcategory TEXT,
  cost_price REAL NOT NULL,
  markup_percent REAL DEFAULT 0,
  markup_amount REAL DEFAULT 0,
  selling_price REAL NOT NULL,
  weight REAL DEFAULT 0,
  stock_quantity INTEGER DEFAULT 0,
  image_url TEXT,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS orders (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id),
  subtotal REAL NOT NULL,
  discount REAL DEFAULT 0,
  delivery_fee REAL DEFAULT 0,
  total_amount REAL NOT NULL,
  status TEXT DEFAULT 'PENDING' CHECK (status IN ('PENDING', 'PAID', 'PROCESSING', 'SHIPPED', 'DELIVERED')),
  delivery_address TEXT,
  city TEXT,
  total_weight REAL DEFAULT 0,
  payment_method TEXT DEFAULT 'STITCH',
  stitch_payment_id TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS order_items (
  id TEXT PRIMARY KEY,
  order_id TEXT NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id TEXT REFERENCES products(id),
  product_name TEXT,
  quantity INTEGER NOT NULL,
  unit_price REAL NOT NULL,
  weight REAL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS cart_items (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  product_id TEXT NOT NULL REFERENCES products(id),
  quantity INTEGER DEFAULT 1,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, product_id)
);

-- =============================================
-- INDEXES for performance
-- =============================================

CREATE INDEX IF NOT EXISTS idx_products_category ON products(category);
CREATE INDEX IF NOT EXISTS idx_products_active ON products(is_active);
CREATE INDEX IF NOT EXISTS idx_orders_user ON orders(user_id);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
CREATE INDEX IF NOT EXISTS idx_order_items_order ON order_items(order_id);
CREATE INDEX IF NOT EXISTS idx_cart_items_user ON cart_items(user_id);

-- =============================================
-- ENABLE ROW LEVEL SECURITY
-- =============================================

ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE cart_items ENABLE ROW LEVEL SECURITY;

-- =============================================
-- RLS POLICIES
-- Using service role key in API routes bypasses RLS,
-- but we set permissive policies as fallback safety
-- =============================================

-- Products: readable by everyone
CREATE POLICY "Products readable by all" ON products
  FOR SELECT USING (true);

-- Orders: readable/writable by all (API handles auth)
CREATE POLICY "Orders readable by all" ON orders
  FOR SELECT USING (true);
CREATE POLICY "Orders writable by all" ON orders
  FOR ALL USING (true);

-- Order items: readable/writable by all
CREATE POLICY "Order items readable by all" ON order_items
  FOR SELECT USING (true);
CREATE POLICY "Order items writable by all" ON order_items
  FOR ALL USING (true);

-- Cart items: readable/writable by all
CREATE POLICY "Cart items readable by all" ON cart_items
  FOR SELECT USING (true);
CREATE POLICY "Cart items writable by all" ON cart_items
  FOR ALL USING (true);

-- Users: readable/writable by all (API handles auth)
CREATE POLICY "Users readable by all" ON users
  FOR SELECT USING (true);
CREATE POLICY "Users writable by all" ON users
  FOR ALL USING (true);

-- =============================================
-- UPDATED_AT trigger
-- =============================================

CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER products_updated_at
  BEFORE UPDATE ON products
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER orders_updated_at
  BEFORE UPDATE ON orders
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();
